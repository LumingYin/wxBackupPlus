//
//  wxBackupPlus.h
//  wxBackupPlus
//
//  Created by Bright on 9/1/17.
//  Copyright © 2017 Bright. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for wxBackupPlus.
FOUNDATION_EXPORT double wxBackupPlusVersionNumber;

//! Project version string for wxBackupPlus.
FOUNDATION_EXPORT const unsigned char wxBackupPlusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <wxBackupPlus/PublicHeader.h>


